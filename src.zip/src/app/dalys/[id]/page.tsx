"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { doc, onSnapshot, updateDoc, deleteDoc, serverTimestamp} from "firebase/firestore";
import { deleteObject, ref } from "firebase/storage";
import { useParams } from "next/navigation";
import { db, storage } from "@/lib/firebase";
import { useAuth } from "@/lib/useAuth";
import { deleteFile, deleteFolder, uploadImage } from "@/lib/upload";
import PhotoGallery from "@/components/gallery/PhotoGallery";

type Part = {
  id: string;
  title?: string;
  brand?: string;
  model?: string;
  city?: string;
  price?: number;
  phone?: string;
  lat?: number;
  lng?: number;
  ownerUid?: string;
  ownerEmail?: string;
  description?: string;
  desc?: string;
  imageUrls?: string[];
  imagePaths?: string[];
};

export default function PartDetailPage() {
  const { user } = useAuth();
  const params = useParams<{ id: string }>();
  const id = params?.id;

  const [data, setData] = useState<Part | null>(null);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const [eTitle, setETitle] = useState("");
  const [eBrand, setEBrand] = useState("");
  const [eModel, setEModel] = useState("");
  const [eCity, setECity] = useState("");
  const [ePrice, setEPrice] = useState("");
  const [ePhone, setEPhone] = useState("");
  const [eDesc, setEDesc] = useState("");

  const [newFiles, setNewFiles] = useState<File[]>([]);


  useEffect(() => {
    if (!id) return;
    const ref = doc(db, "parts", id);
    const unsub = onSnapshot(ref, (snap) => {
      setData(snap.exists() ? ({ id: snap.id, ...(snap.data() as any) } as Part) : null);
    });
    return () => unsub();
  }, [id]);
  useEffect(() => {
    if (!data) return;
    setETitle(data.title ?? "");
    setEBrand(data.brand ?? "");
    setEModel(data.model ?? "");
    setECity(data.city ?? "");
    setEPrice(typeof data.price === "number" ? String(data.price) : "");
    setEPhone(data.phone ?? "");
    setEDesc((data.description ?? "") as any);
  }, [data]);


  const isOwner = !!user?.uid && !!data?.ownerUid && data.ownerUid === user.uid;

  const images = useMemo(
    () => (Array.isArray(data?.imageUrls) ? data!.imageUrls!.filter(Boolean) : []),
    [data]
  );


  async function saveEdits() {
    if (!id || !isOwner) return;
    setSaving(true);
    setErr(null);
    setMsg(null);
    try {
      const next: any = {
        title: eTitle.trim() || undefined,
        brand: eBrand.trim() || undefined,
        model: eModel.trim() || undefined,
        city: eCity.trim() || undefined,
        phone: ePhone.trim() || undefined,
        description: eDesc.trim() || undefined,
      };
      if (ePrice.trim()) next.price = Number(ePrice);
      await updateDoc(doc(db, "parts", id), next);
      setMsg("Išsaugota ✅");
    } catch (e: any) {
      setErr(e?.message || "Klaida saugant.");
    } finally {
      setSaving(false);
    }
  }

  async function replacePhotos() {
    if (!id || !isOwner) return;
    if (!newFiles.length) return;
    setSaving(true);
    setErr(null);
    setMsg(null);
    try {
      await deleteFolder(`parts/${user!.uid}/${id}`);
      const imageUrls: string[] = [];
      const imagePaths: string[] = [];
      for (const f of newFiles) {
        const safeName = (f.name || "foto.jpg").replace(/[^a-zA-Z0-9._-]/g, "_");
        const path = `parts/${user!.uid}/${id}/${crypto.randomUUID?.() ?? Date.now()}-${safeName}`;
        const url = await uploadImage({ path, file: f });
        imageUrls.push(url);
        imagePaths.push(path);
      }
      await updateDoc(doc(db, "parts", id), { imageUrls, imagePaths });
      setNewFiles([]);
      setMsg("Nuotraukos atnaujintos ✅");
    } catch (e: any) {
      setErr(e?.message || "Klaida atnaujinant nuotraukas.");
    } finally {
      setSaving(false);
    }
  }


  async function setPrimaryPhoto(index: number) {
  if (!id || !isOwner || !data?.imageUrls?.length) return;

  const urls = [...(data.imageUrls || [])];
  if (index <= 0 || index >= urls.length) return;

  // move chosen url to front
  const [u0] = urls.splice(index, 1);
  urls.unshift(u0);

  // paths are optional (older ads may not have them)
  const pathsRaw = Array.isArray(data.imagePaths) ? [...data.imagePaths] : null;
  const hasValidPaths = !!pathsRaw && pathsRaw.length === (data.imageUrls || []).length;

  setSaving(true);
  setErr(null);
  try {
    if (hasValidPaths) {
      const paths = pathsRaw!;
      const [p0] = paths.splice(index, 1);
      paths.unshift(p0);
      await updateDoc(doc(db, "parts", id), { imageUrls: urls, imagePaths: paths });
    } else {
      await updateDoc(doc(db, "parts", id), { imageUrls: urls });
    }
    setMsg("Pagrindinė nuotrauka pakeista ✅");
  } catch (e: any) {
    setErr(e?.message || "Klaida keičiant pagrindinę nuotrauką.");
  } finally {
    setSaving(false);
  }
}

async function deleteOnePhoto(index: number) {
  if (!id || !isOwner || !data?.imageUrls?.length) return;
  if (!confirm("Ištrinti šią nuotrauką?")) return;

  const urls = [...(data.imageUrls || [])];
  const url = urls[index];
  urls.splice(index, 1);

  const pathsRaw = Array.isArray(data.imagePaths) ? [...data.imagePaths] : null;
  const hasValidPaths = !!pathsRaw && pathsRaw.length === (data.imageUrls || []).length;

  setSaving(true);
  setErr(null);
  try {
    // try delete from Storage (works for both path + download URL)
    if (hasValidPaths) {
      const paths = pathsRaw!;
      const path = paths[index];
      paths.splice(index, 1);
      if (path) await deleteFile(path);
      await updateDoc(doc(db, "parts", id), { imageUrls: urls, imagePaths: paths });
    } else {
      if (url) {
        try {
          await deleteObject(ref(storage, url));
        } catch {
          // ignore if it's an external URL or already deleted
        }
      }
      await updateDoc(doc(db, "parts", id), { imageUrls: urls });
    }

    setMsg("Nuotrauka ištrinta ✅");
  } catch (e: any) {
    setErr(e?.message || "Klaida trinant nuotrauką.");
  } finally {
    setSaving(false);
  }
}
  async function movePhoto(index: number, dir: -1 | 1) {
    if (!id || !isOwner) return;
    const next = index + dir;
    if (next < 0 || next >= images.length) return;

    const urls = [...images];
    const tmp = urls[index];
    urls[index] = urls[next];
    urls[next] = tmp;

    const pathsSrc = Array.isArray(data?.imagePaths) ? (data?.imagePaths as any[]) : [];
    let paths: any[] | undefined = undefined;
    if (pathsSrc.length === images.length) {
      paths = [...pathsSrc];
      const t2 = paths[index];
      paths[index] = paths[next];
      paths[next] = t2;
    }

    await updateDoc(doc(db, 'parts', id), {
      imageUrls: urls,
      ...(paths ? { imagePaths: paths } : {}),
      updatedAt: serverTimestamp(),
    });
  }

  async function replaceOnePhoto(index: number, file: File) {
    if (!id || !isOwner || !user) return;
    if (!file) return;

    const urls = [...images];
    if (!urls[index]) return;

    const newPath = `parts/${user.uid}/${id}/${Date.now()}_${file.name}`;
    const newUrl = await uploadImage({ path: newPath, file });

    try {
      const pathsSrc = Array.isArray(data?.imagePaths) ? (data?.imagePaths as any[]) : [];
      if (pathsSrc.length === images.length && pathsSrc[index]) {
        await deleteObject(ref(storage, String(pathsSrc[index])));
      } else {
        await deleteObject(ref(storage, urls[index]));
      }
    } catch {}

    urls[index] = newUrl;

    const pathsSrc = Array.isArray(data?.imagePaths) ? (data?.imagePaths as any[]) : [];
    let paths: any[] | undefined = undefined;
    if (pathsSrc.length === images.length) {
      paths = [...pathsSrc];
      paths[index] = newPath;
    } else {
      paths = new Array(images.length).fill(null);
      paths[index] = newPath;
    }

    await updateDoc(doc(db, 'parts', id), {
      imageUrls: urls,
      imagePaths: paths,
      updatedAt: serverTimestamp(),
    });
  }





  async function copyPhone() {
    const p = (data?.phone || "").toString().trim();
    if (!p) return;
    try {
      await navigator.clipboard.writeText(p);
      setMsg("Telefono numeris nukopijuotas ✅");
    } catch {
      // ignore
    }
  }

  async function deleteListing() {
    if (!id || !isOwner) return;
    if (!confirm("Tikrai ištrinti skelbimą?")) return;
    setSaving(true);
    setErr(null);
    try {
      await deleteFolder(`parts/${user!.uid}/${id}`);
      await deleteDoc(doc(db, "parts", id));
      window.location.href = "/mano";
    } catch (e: any) {
      setErr(e?.message || "Klaida trinant.");
    } finally {
      setSaving(false);
    }
  }

  if (!id) {
    return (
      <main className="mx-auto max-w-6xl px-4 py-6">
        <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-8 text-white/70">Kraunasi…</div>
      </main>
    );
  }

  if (data === null) {
    return (
      <main className="mx-auto max-w-6xl px-4 py-6">
        <Link href="/dalys" className="text-sm font-extrabold text-white/80 hover:text-white">
          ← Atgal
        </Link>
        <div className="mt-4 rounded-3xl border border-white/10 bg-white/[0.03] p-8 text-white/70">
          Skelbimas nerastas arba kraunasi…
        </div>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-6xl px-4 py-6">
      <div className="flex items-center justify-between gap-3">
        <Link href="/dalys" className="text-sm font-extrabold text-white/80 hover:text-white">
          ← Atgal
        </Link>
        <div className="flex items-center gap-2">
          <Link
            href="/dalys/map"
            className="rounded-full border border-white/12 bg-white/[0.04] px-4 py-2 text-sm font-extrabold text-white/85 hover:bg-white/[0.08]"
          >
            Žemėlapis
          </Link>
          <Link
            href="/ikelti"
            className="rounded-full bg-white px-4 py-2 text-sm font-extrabold text-black hover:bg-white/90"
          >
            ➕ Įkelti
          </Link>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-5 2xl:grid-cols-[minmax(0,1fr)_340px]">
        <div className="min-w-0 space-y-4">
          <PhotoGallery images={images} editable={isOwner} onSetPrimary={setPrimaryPhoto} onDelete={deleteOnePhoto} onMove={movePhoto} onReplace={replaceOnePhoto} />

          <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="text-sm font-extrabold text-white/60">🧩 Dalys</div>
                <h1 className="mt-1 text-2xl font-black">{data.title || "Detalė"}</h1>
                <div className="mt-2 text-sm text-white/65">
                  {[data.city, [data.brand, data.model].filter(Boolean).join(" ")].filter(Boolean).join(" • ")}
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs font-extrabold text-white/60">Kaina</div>
                <div className="text-2xl font-black">
                  {typeof data.price === "number" ? `${data.price} €` : "—"}
                </div>
              </div>
            </div>

            <div className="mt-4 whitespace-pre-wrap text-sm text-white/80">
              {(data.description ?? data.desc ?? "").toString() || "—"}
            </div>
          </div>
        </div>

        <aside className="min-w-0 space-y-4 2xl:sticky 2xl:top-4 self-start">
          <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-5">
            <div className="text-xs font-extrabold text-white/60">Kontaktai</div>

            {typeof data.lat === "number" && typeof data.lng === "number" ? (
              <div className="mt-4 rounded-2xl border border-white/10 bg-white/[0.02] p-3">
                <div className="text-xs font-extrabold text-white/60">Vieta</div>
                <div className="mt-2 overflow-hidden rounded-xl border border-white/10">
                  <iframe
                    title="map"
                    className="h-36 w-full"
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    src={`https://www.google.com/maps?q=${data.lat},${data.lng}&z=12&output=embed`}
                  />
                </div>
                <a
                  className="mt-3 inline-flex w-full items-center justify-center rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 text-sm font-extrabold text-white/90 hover:bg-white/[0.08]"
                  href={`https://www.google.com/maps/dir/?api=1&destination=${data.lat},${data.lng}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  🧭 Naviguoti
                </a>
              </div>
            ) : null}

            {data.phone ? (
              <div className="mt-3 space-y-2">
                <div className="flex items-center justify-between gap-2 rounded-2xl border border-white/12 bg-white/5 px-4 py-3">
                  <div className="text-sm font-extrabold text-white/90">{data.phone}</div>
                  <button
                    type="button"
                    onClick={copyPhone}
                    className="rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 text-xs font-extrabold text-white/90 hover:bg-white/[0.08]"
                  >
                    Kopijuoti
                  </button>
                </div>

                <a
                  href={`tel:${data.phone}`}
                  className="inline-flex w-full items-center justify-center rounded-2xl bg-white px-4 py-3 text-sm font-extrabold text-black hover:bg-white/90"
                >
                  📞 Skambinti
                </a>
              </div>
            ) : (
              <div className="mt-3 rounded-2xl border border-white/12 bg-white/5 px-4 py-3 text-center text-sm text-white/55">
                Telefono nėra
              </div>
            )}
          </div>


          {isOwner ? (
            <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-5">
              <div className="text-sm font-black">Valdymas</div>
              {err ? <div className="mt-2 rounded-2xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-200">{err}</div> : null}
              {msg ? <div className="mt-2 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-200">{msg}</div> : null}

              <div className="mt-3 grid grid-cols-1 gap-2">
                <input value={eTitle} onChange={(e) => setETitle(e.target.value)} placeholder="Pavadinimas" className="w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none placeholder:text-white/35 focus:border-white/20" />
                <input value={eBrand} onChange={(e) => setEBrand(e.target.value)} placeholder="Markė" className="w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none placeholder:text-white/35 focus:border-white/20" />
                <input value={eModel} onChange={(e) => setEModel(e.target.value)} placeholder="Modelis" className="w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none placeholder:text-white/35 focus:border-white/20" />
                <input value={eCity} onChange={(e) => setECity(e.target.value)} placeholder="Miestas" className="w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none placeholder:text-white/35 focus:border-white/20" />
                <input value={ePrice} onChange={(e) => setEPrice(e.target.value)} placeholder="Kaina" inputMode="numeric" className="w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none placeholder:text-white/35 focus:border-white/20" />
                <input value={ePhone} onChange={(e) => setEPhone(e.target.value)} placeholder="Telefonas" className="w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none placeholder:text-white/35 focus:border-white/20" />
                <textarea value={eDesc} onChange={(e) => setEDesc(e.target.value)} placeholder="Aprašymas" rows={4} className="w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none placeholder:text-white/35 focus:border-white/20" />
              </div>

              <button onClick={saveEdits} disabled={saving} className="mt-3 w-full rounded-2xl bg-white px-4 py-3 text-sm font-extrabold text-black hover:bg-white/90 disabled:opacity-60">
                💾 Išsaugoti
              </button>

              <div className="mt-4 text-xs font-extrabold text-white/60">Nuotraukos</div>
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={(e) => setNewFiles(Array.from(e.target.files || []))}
                className="mt-2 w-full rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white/80"
              />
              <button onClick={replacePhotos} disabled={saving || !newFiles.length} className="mt-2 w-full rounded-2xl border border-white/12 bg-white/[0.04] px-4 py-3 text-sm font-extrabold text-white/90 hover:bg-white/[0.08] disabled:opacity-60">
                🔁 Atnaujinti nuotraukas
              </button>

              <button onClick={deleteListing} disabled={saving} className="mt-4 w-full rounded-2xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm font-extrabold text-red-200 hover:bg-red-500/15 disabled:opacity-60">
                🗑️ Ištrinti skelbimą
              </button>
            </div>
          ) : null}

        </aside>
      </div>
    </main>
  );
}
